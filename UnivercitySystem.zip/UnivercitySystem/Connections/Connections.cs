﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UnivercitySystem.Connections
{
    internal static class Connections
    {
        public const string sqlConStr = """
                Server = DESKTOP-4OKEOFD;
                Database = UniversitySystem;
                User Id = sa;
                Password = 123;
                TrustServerCertificate = True;
            """;
    }
}
